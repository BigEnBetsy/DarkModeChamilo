const STYLE_ID = "chamilo-dark-mode-style";

// Hoeveel donkerder de blauwtinten worden (0.05 = beetje, 0.2 = veel)
const BLUE_DARKEN = 0.12;

console.log("[Chamilo Dark Mode] content script geladen op", location.href);

const css = `
  html {
    filter: invert(1) hue-rotate(180deg) !important;
    background: #fff !important;
  }

  /* Media terug omdraaien zodat ze er normaal uitzien */
  img, video, picture, canvas, svg image,
  iframe[src*="youtube"], iframe[src*="youtu.be"], iframe[src*="vimeo"],
  iframe[src*="teams.microsoft"], iframe[src*="microsoftstream"],
  iframe[src*="panopto"], iframe[src*="kaltura"] {
    filter: invert(1) hue-rotate(180deg) !important;
  }

  /* ---- PDF's: niet donker maken, gewoon normaal (wit) ---- */
  iframe[src*="pdf" i],
  iframe[src*="viewer" i],
  iframe[data-src*="pdf" i],
  embed[type="application/pdf"],
  embed[src*="pdf" i],
  object[type="application/pdf"],
  object[data*="pdf" i] {
    filter: invert(1) hue-rotate(180deg) !important;
  }

  /* Achtergrondafbeeldingen terug omdraaien */
  [style*="background-image"] {
    filter: invert(1) hue-rotate(180deg) !important;
  }

  /* Geen dubbele inversie voor geneste media */
  img img, video img, [style*="background-image"] img {
    filter: none !important;
  }

  /* ---- Zwarte iconen ----
     Voor de inversie moeten ze wit zijn, dan worden ze zwart. */

  /* Icoonlettertypes (mdi / Font Awesome) in menu en tegels */
  html body nav [class*="mdi-"], html body nav [class^="fa-"], html body nav [class*=" fa-"],
  html body .navbar [class*="mdi-"], html body .navbar [class^="fa-"], html body .navbar [class*=" fa-"],
  html body .menu-item [class*="mdi-"], html body .menu-item [class^="fa-"],
  html body .thumbnail [class*="mdi-"], html body .thumbnail [class^="fa-"],
  html body .panel [class*="mdi-"], html body .panel [class^="fa-"], html body .panel [class*=" fa-"] {
    color: #fff !important;
  }

  /* Afbeeldings-/SVG-iconen in menu en tegels (logo en profielfoto uitgezonderd) */
  html body nav img:not([src*="logo"]):not([src*="avatar"]):not([src*="profile"]),
  html body .navbar img:not([src*="logo"]):not([src*="avatar"]):not([src*="profile"]),
  html body .menu-item img,
  html body .thumbnail img,
  html body a > img[src$=".svg"]:not([src*="logo"]) {
    filter: brightness(0) invert(1) !important;
  }

  /* ---- Actief menu-item: icoon licht (op de donkere achtergrond) ----
     Voor de inversie zwart = na de inversie wit.
     Wil je lichtblauw? Vervang #000 door #0b2f52. */

  html body nav .active [class*="mdi-"], html body nav .active [class^="fa-"], html body nav .active [class*=" fa-"],
  html body .navbar .active [class*="mdi-"], html body .navbar .active [class^="fa-"], html body .navbar .active [class*=" fa-"],
  html body nav [aria-current] [class*="mdi-"], html body nav [aria-current] [class^="fa-"], html body nav [aria-current] [class*=" fa-"],
  html body nav .active i, html body .navbar .active i,
  html body nav .active svg, html body .navbar .active svg,
  html body nav .active svg *, html body .navbar .active svg * {
    color: #000 !important;
    fill: #000 !important;
  }

  /* Afbeeldings-/SVG-iconen van het actieve item */
  html body nav .active img:not([src*="logo"]):not([src*="avatar"]):not([src*="profile"]),
  html body .navbar .active img:not([src*="logo"]):not([src*="avatar"]):not([src*="profile"]),
  html body nav [aria-current] img:not([src*="logo"]):not([src*="avatar"]):not([src*="profile"]) {
    filter: brightness(0) !important;
  }
`;

/* ---------- Blauwtinten donkerder maken ---------- */

const seen = new WeakSet();
const changed = new Map(); // element -> { value, priority }

function parseColor(str) {
  const m = str.match(/rgba?\(([^)]+)\)/);
  if (!m) return null;
  const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number);
  if (p.length < 3) return null;
  return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
}

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  const d = max - min;
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1));
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s, l };
}

function hslToRgb(h, s, l) {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  return [r, g, b].map((v) => Math.round((v + m) * 255));
}

function processElement(el) {
  if (seen.has(el)) return;
  seen.add(el);

  const c = parseColor(getComputedStyle(el).backgroundColor);
  if (!c || c.a === 0) return;

  const { h, s, l } = rgbToHsl(c.r, c.g, c.b);

  // De pagina wordt geinverteerd: een donkere blauwe achtergrond wordt
  // lichtblauw. Om het resultaat donkerder te maken, maken we het origineel lichter.
  if (h >= 190 && h <= 250 && s >= 0.3 && l >= 0.2 && l <= 0.65) {
    const newL = Math.min(l + BLUE_DARKEN, 0.85);
    const [r, g, b] = hslToRgb(h, s, newL);
    changed.set(el, {
      value: el.style.getPropertyValue("background-color"),
      priority: el.style.getPropertyPriority("background-color"),
    });
    el.style.setProperty("background-color", `rgba(${r}, ${g}, ${b}, ${c.a})`, "important");
  }
}

function scanAll() {
  window.CDMCyber && window.CDMCyber.ensure();
  document.querySelectorAll("*").forEach(processElement);
}

function restoreAll() {
  for (const [el, orig] of changed) {
    if (orig.value) el.style.setProperty("background-color", orig.value, orig.priority);
    else el.style.removeProperty("background-color");
  }
  changed.clear();
}

/* ---------- Aan/uit ---------- */

let observer = null;
let scheduled = false;

function scheduleScan() {
  if (scheduled) return;
  scheduled = true;
  setTimeout(() => {
    scheduled = false;
    scanAll();
  }, 250);
}

function startObserver() {
  if (observer) return;
  observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, { childList: true, subtree: true });
}

function stopObserver() {
  observer?.disconnect();
  observer = null;
}

function apply() {
  if (!document.getElementById(STYLE_ID)) {
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }
  startObserver();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scanAll, { once: true });
  } else {
    scanAll();
  }
  console.log("[Chamilo Dark Mode] stijl toegepast");
}

function remove() {
  document.getElementById(STYLE_ID)?.remove();
  stopObserver();
  restoreAll();
  console.log("[Chamilo Dark Mode] stijl verwijderd");
}

/* ---------- Standen: off | dark | cyber ---------- */

const MODES = ["off", "dark", "cyber"];
const MODE_HINT_KEY = "cdm-mode-hint"; // snelle, synchrone hint zodat er niets flikkert
let currentMode = null;
let rainOpacity = 55;

function setMode(mode) {
  if (mode === currentMode) return;
  currentMode = mode;
  try { localStorage.setItem(MODE_HINT_KEY, mode); } catch (e) {}

  if (mode === "off") {
    window.CDMCyber.stop();
    remove();
  } else if (mode === "dark") {
    window.CDMCyber.stop();
    apply();
  } else {
    apply(); // cyber bouwt voort op de darkmode
    window.CDMCyber.start(rainOpacity);
  }
}

function modeFrom(res) {
  if (MODES.includes(res.mode)) return res.mode;
  return res.enabled === false ? "off" : "dark"; // oude aan/uit-instelling
}

function opacityFrom(value) {
  const v = Number(value);
  return v >= 15 && v <= 100 ? v : 55;
}

// Meteen toepassen op basis van de laatst bekende stand, daarna de echte opgeslagen stand ophalen
let hint = "dark";
try {
  const h = localStorage.getItem(MODE_HINT_KEY);
  if (MODES.includes(h)) hint = h;
} catch (e) {}
setMode(hint);

chrome.storage.local.get(["mode", "enabled", "rainOpacity"], (res) => {
  rainOpacity = opacityFrom(res.rainOpacity);
  window.CDMCyber.setOpacity(rainOpacity);
  setMode(modeFrom(res));
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.rainOpacity) {
    rainOpacity = opacityFrom(changes.rainOpacity.newValue);
    window.CDMCyber.setOpacity(rainOpacity);
  }
  if (changes.mode || changes.enabled) {
    chrome.storage.local.get(["mode", "enabled"], (res) => setMode(modeFrom(res)));
  }
});
