const MODES = ["off", "dark", "cyber"];
const body = document.body;
const radios = document.querySelectorAll('input[name="mode"]');
const slider = document.getElementById("rainOpacity");
const sliderValue = document.getElementById("rainValue");

function modeFrom(res) {
  if (MODES.includes(res.mode)) return res.mode;
  return res.enabled === false ? "off" : "dark"; // oude aan/uit-instelling
}

function show(mode) {
  body.dataset.mode = mode;
  radios.forEach((r) => { r.checked = r.value === mode; });
}

function showOpacity(value) {
  slider.value = value;
  sliderValue.textContent = value + "%";
}

radios.forEach((r) => {
  r.addEventListener("change", () => {
    if (!r.checked) return;
    show(r.value);
    chrome.storage.local.set({ mode: r.value });
  });
});

slider.addEventListener("input", () => {
  showOpacity(slider.value);
  chrome.storage.local.set({ rainOpacity: Number(slider.value) });
});

chrome.storage.local.get(["mode", "enabled", "rainOpacity"], (res) => {
  show(modeFrom(res));
  const v = Number(res.rainOpacity);
  showOpacity(v >= 15 && v <= 100 ? v : 55);
});

/* ---------- Mini-regen in het voorbeeld ---------- */

(function previewRain() {
  const canvas = document.getElementById("preview");
  const g = canvas.getContext("2d");
  const size = 12;
  const cols = Math.floor(canvas.width / size);
  const rows = Math.floor(canvas.height / size) + 1;
  const drops = Array.from({ length: cols }, () => ({
    y: -Math.random() * rows * 2,
    v: 0.12 + Math.random() * 0.2,
  }));

  g.font = `bold ${size}px Consolas, "Courier New", monospace`;
  g.textBaseline = "top";

  function draw() {
    g.fillStyle = "rgba(0, 0, 0, 0.16)";
    g.fillRect(0, 0, canvas.width, canvas.height);
    drops.forEach((d, i) => {
      d.y += d.v;
      const row = Math.floor(d.y);
      if (row >= 0) {
        const ch = Math.random() < 0.5 ? "0" : "1";
        g.fillStyle = "#00ff41";
        g.fillText(ch, i * size, row * size);
        if (row > 0) { g.fillStyle = "#e6ffec"; g.fillText(ch, i * size, row * size); }
      }
      if (row > rows && Math.random() > 0.9) { d.y = -Math.random() * 6; d.v = 0.12 + Math.random() * 0.2; }
    });
  }

  if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
    for (let i = 0; i < 40; i++) draw();
    return;
  }
  setInterval(draw, 60);
})();
