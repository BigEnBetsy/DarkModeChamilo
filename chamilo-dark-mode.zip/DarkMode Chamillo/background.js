// Toolbar-icoon: badge laat zien welke stand actief is.
// De keuze zelf gebeurt in het menu (popup.html).

const MODES = ["off", "dark", "cyber"];
const LABELS = { off: "uit", dark: "dark mode", cyber: "cyber attack" };
const NAME = chrome.runtime.getManifest().name;

function modeFrom(res) {
  if (MODES.includes(res.mode)) return res.mode;
  return res.enabled === false ? "off" : "dark"; // oude aan/uit-instelling
}

async function updateBadge() {
  const res = await chrome.storage.local.get(["mode", "enabled"]);
  const mode = modeFrom(res);

  if (mode === "off") {
    chrome.action.setBadgeText({ text: "UIT" });
    chrome.action.setBadgeBackgroundColor({ color: "#6b7280" });
  } else if (mode === "cyber") {
    chrome.action.setBadgeText({ text: "01" });
    chrome.action.setBadgeBackgroundColor({ color: "#00c832" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
  try { chrome.action.setBadgeTextColor({ color: mode === "cyber" ? "#000000" : "#ffffff" }); } catch (e) {}
  chrome.action.setTitle({ title: `${NAME}: ${LABELS[mode]}` });
}

chrome.runtime.onInstalled.addListener(async () => {
  const res = await chrome.storage.local.get(["mode", "enabled"]);
  if (!MODES.includes(res.mode)) {
    await chrome.storage.local.set({ mode: modeFrom(res) });
  }
  updateBadge();
});

chrome.runtime.onStartup.addListener(updateBadge);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.mode || changes.enabled)) updateBadge();
});

updateBadge();
