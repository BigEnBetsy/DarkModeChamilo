/*
 * Cyber attack-modus: groene matrix-look + binaire regen (0 en 1).
 *
 * Bouwt voort op de darkmode: de pagina is al geinverteerd (invert + hue-rotate).
 * Daar komt een SVG-kleurfilter achteraan dat alles naar een groene
 * fosfor-kleurenschaal afbeeldt (zwart -> donkergroen -> matrixgroen -> mintwit),
 * plus scanlines/vignet en een canvas met vallende nullen en enen.
 */
(() => {
  const IDS = {
    style: "cdm-cyber-style",
    svg: "cdm-cyber-svg",
    canvas: "cdm-cyber-rain",
    crt: "cdm-cyber-crt",
  };
  const FILTER_ID = "cdm-cyber-map";
  const SVG_NS = "http://www.w3.org/2000/svg";

  // Kleurenschaal: helderheid (0..1, 11 stappen) -> rgb
  const RAMP_R = "0 0 0 0 0 .02 .03 .04 .06 .10 .85";
  const RAMP_G = "0 .09 .18 .28 .39 .51 .64 .77 .89 .97 1";
  const RAMP_B = "0 .03 .05 .08 .11 .15 .19 .23 .28 .34 .85";

  /*
   * Let op: alles wat hier gekleurd wordt, ligt binnen de geinverteerde <html>.
   * Wit in deze CSS wordt dus zwart op het scherm (dat gebruiken we voor
   * scanlines en vignet). Het regen-canvas krijgt hetzelfde tegenfilter als
   * afbeeldingen, zodat de kleuren die we tekenen ongewijzigd doorkomen.
   */
  const CSS = `
    html:root {
      filter: invert(1) hue-rotate(180deg) url(#${FILTER_ID}) !important;
      background: #fff !important;
      scrollbar-color: #00c832 #020a04;
    }
    html:root body * { scrollbar-color: #4d4d4d #f7f7f7; }

    html:root ::selection { background: #464646 !important; color: #fff !important; }

    html:root h1, html:root h2, html:root h3, html:root h4,
    html:root a, html:root button, html:root .btn, html:root nav, html:root label {
      text-shadow: 0 0 6px rgba(0, 0, 0, .28);
    }

    html:root #${IDS.canvas} {
      position: fixed !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      filter: invert(1) hue-rotate(180deg) !important;
      transition: opacity .9s ease;
    }

    html:root #${IDS.crt} {
      position: fixed !important;
      inset: 0 !important;
      pointer-events: none !important;
      z-index: 2147483646 !important;
      background:
        repeating-linear-gradient(to bottom,
          rgba(255, 255, 255, .07) 0, rgba(255, 255, 255, .07) 1px,
          transparent 1px, transparent 3px),
        radial-gradient(ellipse at center,
          transparent 55%, rgba(255, 255, 255, .55) 100%);
    }
  `;

  let active = false;
  let opacity = 55;

  /* ---------- Elementen ---------- */

  function svgEl(name, attrs) {
    const el = document.createElementNS(SVG_NS, name);
    for (const k in attrs) el.setAttribute(k, attrs[k]);
    return el;
  }

  function buildSvg() {
    const svg = svgEl("svg", {
      id: IDS.svg, width: "0", height: "0", "aria-hidden": "true", focusable: "false",
    });
    svg.style.cssText = "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none";

    const filter = svgEl("filter", {
      id: FILTER_ID, "color-interpolation-filters": "sRGB",
      x: "0", y: "0", width: "100%", height: "100%",
    });
    // Alles eerst naar helderheid (grijs) ...
    filter.appendChild(svgEl("feColorMatrix", {
      type: "matrix",
      values: "0.2126 0.7152 0.0722 0 0  0.2126 0.7152 0.0722 0 0  0.2126 0.7152 0.0722 0 0  0 0 0 1 0",
    }));
    // ... en die helderheid dan op de groene schaal zetten
    const transfer = svgEl("feComponentTransfer", {});
    transfer.appendChild(svgEl("feFuncR", { type: "table", tableValues: RAMP_R }));
    transfer.appendChild(svgEl("feFuncG", { type: "table", tableValues: RAMP_G }));
    transfer.appendChild(svgEl("feFuncB", { type: "table", tableValues: RAMP_B }));
    filter.appendChild(transfer);

    svg.appendChild(filter);
    return svg;
  }

  function buildStyle() {
    const style = document.createElement("style");
    style.id = IDS.style;
    style.textContent = CSS;
    return style;
  }

  function buildCrt() {
    const div = document.createElement("div");
    div.id = IDS.crt;
    div.setAttribute("aria-hidden", "true");
    return div;
  }

  function buildCanvas() {
    const canvas = document.createElement("canvas");
    canvas.id = IDS.canvas;
    canvas.setAttribute("aria-hidden", "true");
    return canvas;
  }

  /* ---------- Binaire regen ---------- */

  const FONT_PX = 16;      // grootte van een cijfer (css-pixels)
  const LEVELS = 10;       // helderheidsniveaus van de staart
  const FRAME_MS = 33;     // ~30 beelden per seconde

  let ctx = null;
  let raf = 0;
  let lastTime = 0;
  let cell = 16;
  let rows = 0;
  let columns = [];
  let sprites = [];        // sprites[cijfer][niveau]; niveau LEVELS = kop
  let resizeTimer = 0;

  function makeSprite(char, fill) {
    const c = document.createElement("canvas");
    c.width = c.height = cell;
    const g = c.getContext("2d");
    g.font = `bold ${Math.round(cell * 0.92)}px Consolas, "Courier New", monospace`;
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillStyle = fill;
    g.fillText(char, cell / 2, cell / 2 + cell * 0.04);
    return c;
  }

  function buildSprites() {
    sprites = ["0", "1"].map((ch) => {
      const list = [];
      for (let lv = 0; lv < LEVELS; lv++) {
        const t = (lv + 1) / LEVELS;
        const grey = Math.round(120 + 100 * t);
        list.push(makeSprite(ch, `rgba(${grey},${grey},${grey},${Math.pow(t, 1.3).toFixed(3)})`));
      }
      list.push(makeSprite(ch, "#ffffff")); // kop van de druppel
      return list;
    });
  }

  function newColumn(rowCount, fresh) {
    const len = 10 + Math.random() * 22;
    return {
      y: fresh ? -Math.random() * rowCount * 1.4 - len : -Math.random() * rowCount * 0.6 - len,
      speed: 0.18 + Math.random() * 0.42, // rijen per beeld
      len,
      chars: Uint8Array.from({ length: rowCount + 2 }, () => (Math.random() < 0.5 ? 0 : 1)),
    };
  }

  function sizeCanvas() {
    const canvas = document.getElementById(IDS.canvas);
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cell = Math.max(8, Math.round(FONT_PX * dpr));
    canvas.width = Math.ceil(window.innerWidth * dpr);
    canvas.height = Math.ceil(window.innerHeight * dpr);
    ctx = canvas.getContext("2d");
    rows = Math.ceil(canvas.height / cell) + 1;
    const count = Math.ceil(canvas.width / cell);
    buildSprites();
    columns = Array.from({ length: count }, () => newColumn(rows, true));
  }

  function frame(time) {
    raf = requestAnimationFrame(frame);
    if (time - lastTime < FRAME_MS || !ctx) return;
    const dt = Math.min((time - lastTime) / FRAME_MS, 3);
    lastTime = time;

    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    for (let i = 0; i < columns.length; i++) {
      const col = columns[i];
      col.y += col.speed * dt;
      const head = Math.floor(col.y);

      if (head - col.len > rows) {
        columns[i] = newColumn(rows, false);
        continue;
      }

      const x = i * cell;
      for (let k = 0; k < col.len; k++) {
        const r = head - k;
        if (r < 0 || r >= rows) continue;
        if (Math.random() < 0.015) col.chars[r] = Math.random() < 0.5 ? 0 : 1;
        const level = k === 0
          ? LEVELS
          : Math.min(LEVELS - 1, Math.floor(Math.pow(1 - k / col.len, 1.4) * LEVELS));
        ctx.drawImage(sprites[col.chars[r]][level], x, r * cell);
      }
    }
  }

  function onResize() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(sizeCanvas, 150);
  }

  /* ---------- Aan / uit ---------- */

  function root() {
    return document.documentElement;
  }

  function mount() {
    const r = root();
    if (!r) return;
    if (!document.getElementById(IDS.style)) r.appendChild(buildStyle());
    if (!document.getElementById(IDS.svg)) r.appendChild(buildSvg());
    if (!document.getElementById(IDS.crt)) r.appendChild(buildCrt());
    if (!document.getElementById(IDS.canvas)) {
      const canvas = buildCanvas();
      canvas.style.opacity = "0";
      r.appendChild(canvas);
      sizeCanvas();
      requestAnimationFrame(() => { canvas.style.opacity = String(opacity / 100); });
    }
  }

  function start(value) {
    if (typeof value === "number") opacity = value;
    if (active) { setOpacity(opacity); ensure(); return; }
    active = true;
    mount();
    window.addEventListener("resize", onResize);
    lastTime = 0;
    raf = requestAnimationFrame(frame);
  }

  function stop() {
    if (!active) return;
    active = false;
    cancelAnimationFrame(raf);
    clearTimeout(resizeTimer);
    window.removeEventListener("resize", onResize);
    Object.values(IDS).forEach((id) => document.getElementById(id)?.remove());
    ctx = null;
    columns = [];
    sprites = [];
  }

  // Pagina die onze elementen weggooit? Dan zetten we ze terug.
  function ensure() {
    if (!active) return;
    const missingCanvas = !document.getElementById(IDS.canvas);
    mount();
    if (missingCanvas) lastTime = 0;
  }

  function setOpacity(value) {
    opacity = value;
    const canvas = document.getElementById(IDS.canvas);
    if (canvas) canvas.style.opacity = String(value / 100);
  }

  window.CDMCyber = { start, stop, ensure, setOpacity };
})();
